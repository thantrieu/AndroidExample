package net.braniumacademy.changelanguage

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var btnChangeToVi: Button
    private lateinit var btnChangeToEn: Button

    override fun attachBaseContext(newBase: Context?) {
        val localeToSwitch = Locale(ContextUtils.language)
        val localeUpdatedContext = newBase?.let {
            ContextUtils.updateLocale(it, localeToSwitch)
        }
        super.attachBaseContext(localeUpdatedContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnChangeToVi = findViewById(R.id.btn_change_to_vi)
        btnChangeToEn = findViewById(R.id.btn_change_to_en)

        btnChangeToVi.setOnClickListener { changeLanguage(btnChangeToVi) }
        btnChangeToEn.setOnClickListener { changeLanguage(btnChangeToEn) }
    }

    private fun changeLanguage(view: View) {
        when(view) {
            btnChangeToEn -> {
                ContextUtils.language = "en"
            }
            btnChangeToVi -> {
                ContextUtils.language = "vi"
            }
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}