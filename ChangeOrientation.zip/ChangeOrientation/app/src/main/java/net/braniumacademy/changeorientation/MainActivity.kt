package net.braniumacademy.changeorientation

import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn_portrait.setOnClickListener { changeOrientation(btn_portrait) }
        btn_landscape.setOnClickListener { changeOrientation(btn_landscape) }
    }

    private fun changeOrientation(view: View) {
        when(view) {
            btn_landscape -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            btn_portrait -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }
}